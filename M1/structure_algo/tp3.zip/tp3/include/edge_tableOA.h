#pragma once

#include <stdint.h>

#include "mesh.h"

struct EdgeTableOA {
	size_t size;
	size_t buckets;
	struct Edge *keys;
	int *vals;
};

void edge_tableOA_initialize(struct EdgeTableOA *et, size_t expected_keys);

void edge_tableOA_dispose(struct EdgeTableOA *et);

void edge_tableOA_clear(struct EdgeTableOA *et);

void edge_tableOA_reserve(struct EdgeTableOA *et, size_t expected_keys);

int* edge_tableOA_get(struct EdgeTableOA *et, struct Edge key);

void edge_tableOA_set_at(struct EdgeTableOA *et, struct Edge key, int val);

