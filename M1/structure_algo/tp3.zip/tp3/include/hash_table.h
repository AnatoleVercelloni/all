#ifndef _HASH_TABLES_H
#define _HASH_TABLES_H

// Implementation d'une table de hachage avec open
// addressing et inclusion des valeurs à l'intérieur
// de la table. La table autorise des clés et des
// valeur de types quelconques mais de longueurs fixes,
// via un appel à memcpy.

struct HashTable {
	unsigned capacity;	// Nbr de slots de la table
	unsigned size;		// Nbr de slots occupés
	unsigned key_len;	// Taille en bytes de chaque clé
	unsigned val_len;	// Taille en bytes de chaque valeur
	void *data;
};

void hash_table_init(struct HashTable *ht, unsigned capacity, 
		unsigned key_len, unsigned val_len);

void *hash_table_find(const struct HashTable *ht, void *key);

void hash_table_insert(struct HashTable *ht, void* key, void *val); 

#endif 
