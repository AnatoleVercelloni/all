#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

#include "mesh.h"
#include "edge_tableOA.h"

static inline bool is_empty(struct Edge key)
{
	return (key.v1 == -1);
}

static inline void set_empty(struct Edge *key)
{
	key->v1 = -1;
}

static inline bool is_equal(struct Edge key1, struct Edge key2)
{
	return (key1.v1 == key2.v1 && key1.v2 == key2.v2);
}

/* Murmur 32 */
static inline uint32_t hash_edge(struct Edge key)
{
	const uint32_t m = 0x5bd1e995;
	const int r = 24;

	uint32_t k;
	uint32_t hash = 0;

	k = key.v1; 
	k *= m;
	k ^= k >> r;
	k *= m;
	hash *= m;
	hash ^= k;
	
	k = key.v2;
	k *= m;
	k ^= k >> r;
	k *= m;
	hash *= m;
	hash ^= k;

	return hash;
}

static inline size_t hash_table_lookup(struct Edge *keys, size_t buckets, struct Edge key)
{
	assert(((buckets - 1) & buckets) == 0);
	size_t mask = buckets - 1;

	size_t bucket = hash_edge(key) & mask;

	for (size_t probe = 0; probe < buckets; probe++) {

		if (is_empty(keys[bucket]) || is_equal(keys[bucket], key)) {
			return bucket;
		}
		/* quadratic probing */
		bucket = (bucket + probe + 1) & mask;
	}
	
	/* we should never reach this point */
	assert(false && "Table is full !\n"); 	
	return 0;
}

static inline bool load_factor_ok(struct EdgeTableOA *et)
{
	/* 66% load factor limit */
	return (et->buckets > et->size + et->size / 2);
}

static void edge_tableOA_grow(struct EdgeTableOA *et, size_t new_buckets)
{
	if (new_buckets <= et->buckets) return;

	assert((new_buckets & (new_buckets - 1)) == 0);

	struct Edge *newk = malloc(new_buckets * sizeof(*newk));
	int *newv = malloc(new_buckets * sizeof(*newv));
	
	for (size_t i = 0; i < new_buckets; ++i) {
		newk[i].v1 = -1;
	}
	
	for (size_t probe = 0; probe < et->buckets; ++probe) {
		
		const struct Edge key = et->keys[probe];
		
		if (key.v1 == -1) continue;

		size_t new_idx = hash_table_lookup(newk, new_buckets, key);
		assert(newk[new_idx].v1 == -1);

		newk[new_idx] = key;
		newv[new_idx] = et->vals[probe];
	}
	
	free(et->keys);
	free(et->vals);
	et->keys = newk;
	et->vals = newv;
	et->buckets = new_buckets;
}

void edge_tableOA_initialize(struct EdgeTableOA *et, size_t expected_keys)
{
	et->buckets = 1; 
	while (et->buckets < (3 * expected_keys / 2))
	{
		et->buckets *= 2;
	}
	
	et->keys = malloc(et->buckets * sizeof(struct Edge));
	et->vals = malloc(et->buckets * sizeof(int));
	assert(et->keys != NULL && et->vals != NULL);

	et->size = 0;

	edge_tableOA_clear(et);
}

void edge_tableOA_dispose(struct EdgeTableOA *et)
{
	et->buckets = 0;
	et->size = 0;

	free(et->keys);
	free(et->vals);
}

void edge_tableOA_clear(struct EdgeTableOA *et)
{
	for (size_t i = 0; i < et->buckets; ++i)
	{
		et->keys[i].v1 = -1;
	}
	et->size = 0;
}

void edge_tableOA_reserve(struct EdgeTableOA *et, size_t expected_keys)
{
	size_t buckets = 1;
	while (buckets < (3 * expected_keys / 2))
	{
		buckets *= 2;
	}

	edge_tableOA_grow(et, buckets);
}

int* edge_tableOA_get(struct EdgeTableOA *et, struct Edge key)
{
	size_t bucket = hash_table_lookup(et->keys, et->buckets, key);
	return (et->keys[bucket].v1 == -1) ? NULL : &et->vals[bucket];
}

void edge_tableOA_set_at(struct EdgeTableOA *et, struct Edge key, int val)
{
	size_t bucket = hash_table_lookup(et->keys, et->buckets, key);
	et->vals[bucket] = val;
	if (et->keys[bucket].v1 == -1) {
		et->keys[bucket] = key;
		et->size++;
		if (!load_factor_ok(et)) {
			edge_tableOA_grow(et, 2 * et->buckets);
			assert(load_factor_ok(et));
		}
	}
}

