#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "hash_table.h"

#define FREE_SLOT 0
#define OCCUPIED_SLOT 1
#define DELETED_SLOT 2

void hash_table_init(struct HashTable *ht, unsigned capacity, 
		unsigned key_len, unsigned val_len) 
{
	ht->capacity = capacity;
	ht->key_len = key_len;
	ht->val_len = val_len;
	ht->size = 0;
	unsigned slot_len = 1 + key_len + val_len;
	ht->data = malloc(capacity * slot_len);
}

/* A general purpose hash function : FNV-1a 32 bits. Cfr :
 * https://en.wikipedia.org/wiki/Fowler%E2%80%93Noll%E2%80%93Vo_hash_function
 */
uint32_t hash_key(void *key, unsigned key_len)
{
	unsigned char *byte = key;
	uint32_t hash = 2166136261;
	while (key_len--) {
		hash ^= *byte++;
		hash *= 16777619;
	}
	return hash;
}

void *hash_table_find(const struct HashTable *ht, void *key)
{
	uint32_t pos = hash_key(key, ht->key_len);
	unsigned slot_len = 1 + ht->key_len + ht->val_len;
	unsigned char *data = ht->data;
	while (1) {
		pos = pos % ht->capacity;
		unsigned char *p = data + pos * slot_len;
		if (p[0] == FREE_SLOT) {
			return NULL;
		}
		if (memcmp(key, p + 1, ht->key_len) == 0) {
			return p + 1 + ht->key_len;
		} else {
			pos++;
		}
	}
}

void hash_table_insert(struct HashTable *ht, void* key, void *val)
{
	uint32_t pos = hash_key(key, ht->key_len);
	unsigned slot_len = 1 + ht->key_len + ht->val_len;
	unsigned char *data = ht->data;
	while (1) {
		pos = pos % ht->capacity;
		unsigned char *p = data + pos * slot_len;
		if (p[0] == FREE_SLOT) {
			memcpy(p + 1, key, ht->key_len);
			memcpy(p + 1 + ht->key_len, val, ht->val_len);
			p[0] = OCCUPIED_SLOT;
			return;
		} else {
			pos++;
		}
	}
}

#undef FREE_SLOT
#undef OCCUPIED_SLOT
#undef DELETED_SLOT

