#include<stdlib.h>
#include<stdio.h>
#include"mesh.h"
#include"mesh_adjacency.h"
#include"mesh_io.h"
#include<time.h>


int main(int argc, char **argv){
  if (argc == 1){
    printf("error: filename exepted\n");
    return 0;
  }
  char *filename = argv[1];
  clock_t temps_initial, temps_final;
  struct Mesh *m = malloc(sizeof(struct Mesh));
  initialize_mesh(m);
  read_mesh_from_wavefront_file(m,filename);
  
  temps_initial = clock();
  /*int *a1 = build_adjacency_table1(m);
  emps_final = clock ();
  printf("adjacency_table1: %f \n",  (double)(temps_final - temps_initial) / CLOCKS_PER_SEC*1000);
  //printf("le 1 ca va\n");*/
  
  temps_initial = clock();
  int *a2 = build_adjacency_table2(m);
  temps_final = clock ();
  printf("adjacency_table2: %f \n",  (double)(temps_final - temps_initial) / CLOCKS_PER_SEC*1000);
  //printf("le 2 ca va\n");*/
  
  temps_initial = clock();
  int *a3 = build_adjacency_table3(m);
  temps_final = clock ();
  printf("adjacency_table3: %f \n",  (double)(temps_final - temps_initial) / CLOCKS_PER_SEC*1000);
  //printf("le 3 ca va\n");
  /*for (int i= 0; i<3*m->ntri; i++){
 
    printf(":%d  %d \n", a2[i], a3[i]);
  }*/
  return 0;
}
  
