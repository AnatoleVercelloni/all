#include<stdlib.h>
#include<stdio.h>
#include"mesh.h"
#include"hash_table.h"
#include"mesh_adjacency.h"



int edge_pos_in_tri(int v1, int v2, struct Triangle t){
	int u = t.v1;
	int v = t.v2;
	int w = t.v3;
	if (v1 == u && v2 == v){
		return 0;
	}
	if (v1 == v && v2 == w){
		return 1;
	}
	if (v1 == w && v2 == u){
		return 2;
	}
	return -1;
}


int tris_are_neighbors(int tri1, int tri2, const struct Mesh *m){
	struct Triangle t1 = m->triangles[tri1];
	struct Triangle t2 = m->triangles[tri2];
	int v1 = t2.v1;
	int v2 = t2.v2;
	int v3 = t2.v3;
	int a = edge_pos_in_tri(v2, v1, t1);
	if (a>=0){
		return a;
	} 
	a = edge_pos_in_tri(v3, v2, t1);
	if (a>=0){
		return a;
	} 
	a = edge_pos_in_tri(v1, v3, t1); 
	if (a>=0){
		return a;
	} 
	return -1;
}

int *build_adjacency_table1(const struct Mesh *m){
	int n = (m->ntri);
	int *T = malloc(3*n*sizeof(int));
	for (int i =0; i<n; i++){
		*(T+i) = -1;
	}
	for (int i = 0; i<n; i++){
		for (int j = 0; j<n; j++){
			int a = tris_are_neighbors(i, j, m);
			if (a>=0){
				*(T+3*i+a) = j;
			}
		}
	}
	return T;
} 
	

struct HashTable *build_edge_table1(const struct Mesh *m){
  struct HashTable *ht = malloc(3*(m->ntri)*sizeof(struct Edge));
  hash_table_init(ht, 3*(m->ntri)+1, sizeof(struct Edge), sizeof(struct Triangle));
  for (int i = 0; i<m->ntri; i++){
	struct Triangle t = m->triangles[i];
	struct Edge *e1 = malloc(sizeof(struct Edge));
	e1->v1 = t.v1;
	 e1->v2 = t.v2;
	 hash_table_insert(ht,(void*)e1, (void*)&i); 
	 struct Edge *e2 =  malloc(sizeof(struct Edge));
	 e2->v1 = t.v2;
	 e2->v2 = t.v3;
	 hash_table_insert(ht, (void*)e2, (void*)&i); 
	  struct Edge *e3 = malloc(sizeof(struct Edge));
	  e3->v1 = t.v3;
	  e3->v2 = t.v1;
	  hash_table_insert(ht, (void*)e3,(void*)&i);
	}
	return ht;
}


int *build_adjacency_table2(const struct Mesh *m){
  
	struct HashTable *ht = build_edge_table1(m);
	int n = m->ntri;
	int *T = malloc(3*n*sizeof(int));
	//printf("edge table ok\n");
	for (int i = 0; i<n; i++){
	  //printf("tour %d\n",i);
		struct Triangle t = m->triangles[i];
		struct Edge *e1 = malloc(sizeof(struct Edge));
		e1->v1 = t.v2;
		e1->v2 = t.v1;
		int *e = (int*)hash_table_find(ht, e1);
		//printf("hash table find1 ok\n");
		if (e != NULL){	
			T[3*i + 0] = *e;
		} 
		struct Edge *e2 = malloc(sizeof(struct Edge));
		e2->v1 = t.v3;
		e2->v2 = t.v2;
		e = (int*)hash_table_find(ht, e2);
		//printf("hash table find2 ok\n");
		if (e != NULL){	
			T[3*i + 1] = *e;
		} 
		struct Edge *e3 = malloc(sizeof(struct Edge));
		e3->v1 = t.v1;
		e3->v2 = t.v3;
		e = (int*)hash_table_find(ht, e3);
		//printf("hash table find3 ok\n");
		if (e != NULL){	
			T[3*i + 2] = *e;
		}
	}
	return T;
} 	


void edge_table_initialize(struct EdgeTable *et, int nvert, int ntri){
	et->head = malloc(nvert*sizeof(int));
	et->next = malloc(3*ntri*sizeof(int));
	for (int i = 0; i<3*ntri; i++){
	  et->next[i] = -1;
	}
	for (int i = 0; i<nvert; i++){
	  et->head[i] = -1;
	}
	return ;
}

void edge_table_dispose(struct EdgeTable *et){
	free(et->head);
	free(et->next);
	
	return ;
}

void edge_table_insert(int v1, int edge_code, struct EdgeTable *et){

  int k = et->head[v1];
  et->head[v1] = edge_code;

  if (k != -1){
 
     et->next[edge_code] = k;
  }
  
  return ;
}


int  edge_table_find(int v1, int v2, const struct EdgeTable *et, const struct Mesh *m){
  int edge_code = et -> head[v1];
  while (edge_code != -1){
    int i = edge_code/3;
    int j = (edge_code+1)%3;
    if (m->triangles[i].idx[j] == v2){
      return edge_code;
    }else{
      edge_code = et->next[edge_code];
    }
  }
  return -1;
}
    
		
struct EdgeTable *build_edge_table3(const struct Mesh *m){
  int n = m->ntri;
  struct EdgeTable *et = malloc(sizeof(struct EdgeTable));
  edge_table_initialize(et, m->nvert, m->ntri);

   for(int i = 0; i<n; i++){
     struct Triangle t = m->triangles[i];

     edge_table_insert(t.v1, 3*i, et);

     edge_table_insert(t.v2, 3*i+1, et);

     edge_table_insert(t.v3, 3*i+2, et);
   } 
   return et;
}


int *build_adjacency_table3(const struct Mesh *m){
  int n =3*m->ntri;
  int *T = malloc(n*sizeof(int));
  struct EdgeTable *et = build_edge_table3(m);
  for (int i = 0; i<m->ntri; i++){
    struct Triangle t = m->triangles[i];
    int v1 = t.v2;
    int v2 = t.v1;
    int edge_code = edge_table_find(v1, v2, et, m);
    if (edge_code != -1){
      T[3*i] = edge_code/3;
    }
    v1 = t.v3;
    v2 = t.v2;
    edge_code = edge_table_find(v1, v2, et, m);
    if (edge_code != -1){
      T[3*i+1] = edge_code/3;
    }
    v1 = t.v1;
    v2 = t.v3;
    edge_code = edge_table_find(v1, v2, et, m);
    if (edge_code != -1){
      T[3*i+2] = edge_code/3;
    }
   
  }
  edge_table_dispose(et);
  return T;
}
