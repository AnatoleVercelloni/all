


A = [i for i in range(5)]
B = A

B = B *5

print(B)
print(A)