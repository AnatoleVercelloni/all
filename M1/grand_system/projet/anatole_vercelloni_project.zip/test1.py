a=[1,2,3,4]
b=a
for i in range (2):
	c = a[i]*0
print (b) 